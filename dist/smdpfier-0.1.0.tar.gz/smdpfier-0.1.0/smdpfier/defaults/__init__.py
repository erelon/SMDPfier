"""Default implementations for SMDPfier components."""

from .durations import (
    ConstantActionDuration,
    ConstantOptionDuration,
    MapActionDuration,
    RandomActionDuration,
    RandomOptionDuration,
)
from .options import RandomStaticLen, RandomVarLen
from .rewards import discounted_sum, mean_rewards, reward_rate, sum_rewards

__all__ = [
    # Option generators
    "RandomStaticLen",
    "RandomVarLen",
    # Duration providers
    "ConstantOptionDuration",
    "RandomOptionDuration",
    "ConstantActionDuration",
    "RandomActionDuration",
    "MapActionDuration",
    # Reward aggregators
    "reward_rate",  # Default and recommended
    "sum_rewards",  # Legacy
    "mean_rewards",
    "discounted_sum",
]
