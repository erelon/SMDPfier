"""Default reward aggregators for SMDPfier."""

from __future__ import annotations

from typing import Callable


def reward_rate(
    rewards: list[float], duration_exec: int, per_action_durations: list[int] | None = None
) -> float:
    """Compute reward rate (sum of rewards / duration).

    This is the **default and recommended** reward aggregator for SMDPfier.
    It computes the reward per unit time, making duration environmentally
    significant and encouraging time-efficient behavior.

    The rate objective: R_macro = sum(rewards) / max(1, duration_exec)

    Args:
        rewards: List of per-primitive rewards from option execution
        duration_exec: Actual duration executed in ticks (>= 0)
        per_action_durations: Optional per-action durations (unused here)

    Returns:
        Reward rate (reward per tick)

    Examples:
        >>> # Same total reward, different durations → different rates
        >>> reward_rate([1.0, 1.0], duration_exec=2)
        1.0
        >>> reward_rate([1.0, 1.0], duration_exec=10)
        0.2

        >>> # Edge case: zero duration
        >>> reward_rate([1.0], duration_exec=0)
        1.0

        >>> # Empty rewards
        >>> reward_rate([], duration_exec=5)
        0.0
    """
    if duration_exec < 0:
        raise ValueError(f"duration_exec must be >= 0, got {duration_exec}")

    total_reward = float(sum(rewards))
    denominator = max(1, int(duration_exec))
    return total_reward / denominator


def sum_rewards(rewards: list[float]) -> float:
    """Sum all rewards in the list (legacy aggregator).

    .. deprecated:: 0.1.0
        Use :func:`reward_rate` instead. This function is kept for backward
        compatibility but does not account for duration, which can lead to
        suboptimal policies that ignore time efficiency.

    Simple summation of all per-primitive rewards collected during
    option execution.

    Args:
        rewards: List of per-primitive rewards from option execution

    Returns:
        Sum of all rewards

    Examples:
        >>> sum_rewards([1.0, -0.5, 2.0])
        2.5

        >>> sum_rewards([])  # Empty list
        0.0
    """
    return sum(rewards)


def mean_rewards(rewards: list[float]) -> float:
    """Compute mean of all rewards in the list.

    Averages the per-primitive rewards, which can help normalize
    rewards across options of different lengths.

    Args:
        rewards: List of per-primitive rewards from option execution

    Returns:
        Mean of all rewards, or 0.0 if list is empty

    Examples:
        >>> mean_rewards([1.0, -0.5, 2.0])
        0.8333333333333334

        >>> mean_rewards([])  # Empty list
        0.0
    """
    if not rewards:
        return 0.0
    return sum(rewards) / len(rewards)


def discounted_sum(gamma: float = 0.99) -> Callable[[list[float]], float]:
    """Create a reward aggregator that applies temporal discounting.

    Returns a function that computes the discounted sum of rewards,
    where earlier rewards are weighted more than later ones. This is
    NOT the same as SMDP discounting (which uses γ^{ticks}).

    Args:
        gamma: Discount factor (0 < gamma <= 1)

    Returns:
        Function that computes discounted sum of reward list

    Examples:
        >>> discount_fn = discounted_sum(gamma=0.9)
        >>> discount_fn([1.0, 1.0, 1.0])  # 1.0 + 0.9*1.0 + 0.81*1.0 = 2.71
        2.71

        >>> discount_fn([])  # Empty list
        0.0
    """
    if not (0 < gamma <= 1.0):
        raise ValueError(f"gamma must be in (0, 1], got {gamma}")

    def _discounted_sum(rewards: list[float]) -> float:
        """Apply temporal discounting to reward sequence."""
        if not rewards:
            return 0.0

        discounted_total = 0.0
        discount_factor = 1.0

        for reward in rewards:
            discounted_total += discount_factor * reward
            discount_factor *= gamma

        return discounted_total

    return _discounted_sum

